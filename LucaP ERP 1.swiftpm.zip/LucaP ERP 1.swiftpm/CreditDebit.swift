import Foundation

enum CreditDebit:Double{
    case credit = -1
    case debit = 1
    
    var name:String{
        switch self{
        case .credit: "Credit"
        case .debit: "Debit"
        }
    }
}

