import Foundation

var globalJournalEntryID = 0

class JournalEntry:Identifiable{
    var id:Int
    var date:Date
    var description:String
    var amount:Double
    var creditDebit:CreditDebit
    
    init( description:String,amount:Double,creditDebit:CreditDebit){
        id = globalJournalEntryID
        globalJournalEntryID += 1
        self.date = Date()
        self.description = description
        self.amount = amount
        self.creditDebit = creditDebit
    
        
        
    }
    
    func numAmount()->Double{
        return amount * creditDebit.rawValue
    }
    
    
}

var testEntries = [
    JournalEntry(description:"Capital", amount: 1000, creditDebit: .credit),
    JournalEntry(description:"Assets", amount: 1000, creditDebit: .debit),
    JournalEntry(description:"Assets", amount: 300, creditDebit: .debit),
    JournalEntry(description:"Assets", amount: 300, creditDebit: .credit),
    JournalEntry(description:"Assets", amount: 100, creditDebit: .debit),
    JournalEntry(description:"Liabilities", amount: 100, creditDebit: .credit),
    JournalEntry(description:"Expenses", amount: 300, creditDebit: .debit),
    JournalEntry(description:"Assets", amount: 300, creditDebit: .credit),
    JournalEntry(description:"Expenses", amount: 200, creditDebit: .debit),
    JournalEntry(description:"Assets", amount: 200, creditDebit: .credit),
    JournalEntry(description:"Asset", amount: 5000, creditDebit: .debit),
    JournalEntry(description:"Revenue", amount: 5000, creditDebit: .credit),
    JournalEntry(description:"COGS", amount: 400, creditDebit: .debit),
    JournalEntry(description:"Assets", amount: 400, creditDebit: .credit),
    
    
    
    
]
